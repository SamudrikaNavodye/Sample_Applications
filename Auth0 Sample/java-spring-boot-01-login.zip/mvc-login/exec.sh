#!/usr/bin/env bash
docker build -t auth0-samples/auth0-spring-boot-mvc-login .
docker run -p 3000:3000 -it auth0-samples/auth0-spring-boot-mvc-login
