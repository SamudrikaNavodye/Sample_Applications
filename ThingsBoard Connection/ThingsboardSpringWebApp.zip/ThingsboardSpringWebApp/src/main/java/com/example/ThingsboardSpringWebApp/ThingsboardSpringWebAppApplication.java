package com.example.ThingsboardSpringWebApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThingsboardSpringWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThingsboardSpringWebAppApplication.class, args);
	}

}
